from django.shortcuts import render, redirect
from django.db import connection
from django.http import HttpResponseRedirect
from .forms import originalDTForm
from django.urls import reverse
import logging
from django.contrib import messages
import os
import random

def sessionRecord(request):
    user = request.GET['id']
    request.session['user'] = user
    return redirect("submitter:submitMain")

def logout(request):
    user = request.session.get('user')
    if user is None:
        return render(request, 'submitter/wrongAccess.html')
    request.session.pop('user')
    request.session.flush()
    return render(request, "submitter/logOut.html")

# 제출자로 로그인했을 경우 초기 페이지로 보내주는 view
# 로그인한 사용자 정보 얻어오기

def submitMain(request):

    #로그인 세션정보 확인 부분
    user = request.session.get('user')
    if user is None:
        return render(request, 'submitter/wrongAccess.html')

    try:
        cursor = connection.cursor()
        # get eval score
        strSql = "SELECT EVALSCORE FROM MEMBER WHERE MEMBER.ID = '%s'"%(user)
        result = cursor.execute(strSql)
        evalscore = cursor.fetchall()

        # get all tasks
        strSql = '''SELECT TASKNAME, EXPLANATION FROM TASK'''
        result = cursor.execute(strSql)
        allTask = cursor.fetchall()

        # applied tasks
        strSql = '''SELECT TASKNAME, ACCEPTED, TASK.ID
                        FROM APPLY, TASK
                        WHERE APPLY.MEMID = '%s' AND TASK.ID = TASKID
                        ORDER BY TASK.ID ASC'''%(user)
        result = cursor.execute(strSql)
        parTask = cursor.fetchall()

        # haven't applied
        strSql = '''SELECT T.TASKNAME, T.ID
                        FROM TASK T
                        WHERE T.TASKNAME NOT IN(
                        SELECT TASKNAME
                                        FROM APPLY, TASK
                                        WHERE TASK.ID = TASKID and APPLY.MEMID = '%s')
                        ORDER BY ID ASC'''%(user)
        result = cursor.execute(strSql)
        nonParTask = cursor.fetchall()

        connection.commit()
        connection.close()

        accepted=[]
        not_accepted=[]
        waiting=[]
        not_applied=[]
        for task in parTask:
            row = {'TaskName': task[0], 'TaskID':task[2]}
            if task[1] == "P":
                accepted.append(row)
            elif task[1] == "NP":
                not_accepted.append(row)
            else:
                waiting.append(row)

        for task in nonParTask:
            row = {'TaskName': task[0], 'TaskID':task[1]}
            not_applied.append(row)

        tasklist = []
        for task in allTask:
            row = {'TaskName': task[0], 'describe':task[1]}
            tasklist.append(row)

        evalscore=evalscore[0][0]

    except:
        connection.rollback()
        print("Failed to get Data")

    return render(request, 'submitter/submitMain.html',
    {'evalscore':evalscore, 'all':tasklist, 'accepted':accepted, 'not_accepted':not_accepted, 'waiting':waiting, 'not_applied':not_applied, 'user':user})

def wrongAccess(request):
    return render(request, 'submitter/wrongAccess.html')

def taskApply(request, taskid):
    user = request.session.get('user')
    if user is None:
        return render(request, 'submitter/wrongAccess.html')

    if request.method == "POST":
        cursor = connection.cursor()
        sql = "INSERT INTO APPLY(MEMID, TASKID) VALUES('{}',{})".format(user, taskid)
        result = cursor.execute(sql)
        connection.commit()
        cursor.close()
        connection.close()
        return redirect("submitter:submitMain")

    else:
        cursor = connection.cursor()
        sql = "SELECT TASKNAME from TASK where ID = {}".format(taskid)
        result=cursor.execute(sql)
        result=cursor.fetchall()[0][0]
        connection.commit()
        connection.close()
        return render(request, 'submitter/taskApply.html', {'taskname':result, 'user':user, 'taskid':taskid})

def taskCancel(request, taskid):
    user = request.session.get('user')
    if user is None:
        return render(request, 'submitter/wrongAccess.html')

    if request.method == "POST":
        cursor = connection.cursor()
        sql = "DELETE FROM APPLY WHERE MEMID = '{}' and TASKID = {}".format(user, taskid)
        result = cursor.execute(sql)
        connection.commit()
        cursor.close()
        connection.close()
        return redirect("submitter:submitMain")
    else:
        return render(request, 'submitter/taskCancel.html')

def datatypeApply(request, taskid):
    user = request.session.get('user')
    if user is None:
        return render(request, 'submitter/wrongAccess.html')

    def get_info():
        cursor=connection.cursor()

        # get all the original data types for the task
        sql = "SELECT NAME, SCHEMAINFO, SCHEMATYPE from ORIGINALDATATYPE where TASKID = {}".format(taskid)
        result = cursor.execute(sql)
        all_datatype = cursor.fetchall()

        # get applied data types but not commited by admin yet
        sql = "SELECT DATATYPE_NAME, SCHEMAINFO, SCHEMATYPE, SUBMITTER, APPLYNUM FROM APPLIED_DATATYPE where TASKID = {}".format(taskid)
        result = cursor.execute(sql)
        all_applied_datatype = cursor.fetchall()

        connection.commit()
        connection.close()

        # fetch result of the query
        all_dt = []
        applied_dt = []

        for dt in all_datatype:
            row={'dtName':dt[0], 'info':dt[1], 'type':dt[2]}
            all_dt.append(row)

        for dt in all_applied_datatype:
            row={'dtName':dt[0], 'info':dt[1], 'type':dt[2], 'submitter':dt[3], 'applynum':dt[4]}
            applied_dt.append(row)

        return all_dt, applied_dt

    if request.method == "POST":
        form = originalDTForm(request.POST)
        if form.is_valid():
            dtname, schemainfo, schematype = form.data['name'], form.data['schemainfo'], form.data['schematype']
            cursor = connection.cursor()
            sql = "INSERT INTO APPLIED_DATATYPE(DATATYPE_NAME, SUBMITTER, TASKID, SCHEMAINFO, SCHEMATYPE) VALUES('{}','{}',{},'{}','{}')".format(dtname, user, taskid, schemainfo, schematype)
            result = cursor.execute(sql)
            connection.commit()
            cursor.close()
            connection.close()
            return redirect('submitter:datatypeApply', taskid = taskid)

    else:
        form = originalDTForm()
        all_dt, applied_dt = get_info()

    return render(request, 'submitter/datatypeApply.html', {'form':form, 'all_dt':all_dt, 'applied_dt':applied_dt, 'user':user, 'taskid':taskid})

def datatypeCancel(request, taskid):
    user = request.session.get('user')
    if user is None:
        return render(request, 'submitter/wrongAccess.html')

    if request.method == "POST":
        applynum = request.POST['applynum']
        if request.POST['form_type'] == "show": # just show the cancel screen
            return render(request, 'submitter/datatypeCancel.html', {'applynum':applynum,'taskid':taskid})
        else: # delete the applied datatype from db
            cursor=connection.cursor()
            sql = "DELETE FROM APPLIED_DATATYPE WHERE APPLYNUM = {}".format(applynum)
            result = cursor.execute(sql)
            connection.commit()
            cursor.close()
            connection.close()
            return redirect('submitter:datatypeApply', taskid = taskid)
    else:
        return redirect('submitter:wrongAccess')

def taskSubmit(request,taskid):

    user = request.session.get('user')
    if user is None:
        return render(request, 'submitter/wrongAccess.html')

    if "GET" == request.method:

        context = []

        try:
            cursor = connection.cursor()
            strSql = '''SELECT NAME, SCHEMAINFO, SERIALNUM, SCHEMATYPE
                             FROM ORIGINALDATATYPE, TASK
                             WHERE ID = '%d'
                             ORDER BY SERIALNUM ASC'''%(taskid)

            result = cursor.execute(strSql)
            originalDataType = cursor.fetchall()


            for data in originalDataType:
                row = {'NAME': data[0], 'SCHEMA': data[1], 'SERIALNUM' : data[2], 'TYPE': data[3]}
                context.append(row)


            strSql = '''SELECT TOTALSUBMISSION
                             FROM APPLY
                             WHERE TASKID = '%d' AND MEMID = '%s'
                             '''%(taskid, user)

            result = cursor.execute(strSql)
            totalSubmission = cursor.fetchall()

            connection.commit()
            connection.close()
            curSubmission = int(totalSubmission[0][0]) + 1

        except:
                connection.rollback()

        return render(request, "submitter/Submitting.html", {'context': context ,'taskId' : taskid,'curSubmission':curSubmission})
    # if not GET, then proceed
    try:

        csv_file = request.FILES["csv_file"]
        if not csv_file.name.endswith('.csv'):
            messages.error(request,'File is not CSV type')
            return HttpResponseRedirect(reverse("submitter:Submitting"))
        #if file is too large, return
        if csv_file.multiple_chunks():
            messages.error(request,"Uploaded file is too big (%.2f MB)." % (csv_file.size/(1000*1000),))
            return HttpResponseRedirect(reverse("submitter:Submitting"))

        file_data = csv_file.read().decode("utf-8")

        lines = file_data.split("\n")
        csv_list = []
        for i in range(len(lines)):
            csv_list.append(lines[i].split(','))


        #폼에서 입력정보 받아오기
        startDate = request.POST['startDate']
        endDate = request.POST['endDate']
        submitNum = request.POST['submitNum']
        schema = request.POST['originalDataType']
        taskId = int(request.POST['taskId'])

        ORIGINALSCHEMALIST = schema.split(',')
        serialNum  = int(ORIGINALSCHEMALIST[-1])
        ORIGINALSCHEMALIST = ORIGINALSCHEMALIST[:len(ORIGINALSCHEMALIST)-1]
        #APPLY테이블에서 totaltuple 추가해주기 위한 정보 받아오기

        #매핑시작
        cursor = connection.cursor()
        strSql = '''SELECT TDTSCHEMA
                         FROM TASKDATATABLE
                         WHERE TASKID = '%d'
                         '''%(taskId)

        result = cursor.execute(strSql)
        TDTSCHEMA = cursor.fetchall()

        TDTSCHEMAORDER = []
        for data in TDTSCHEMA:
            row = {'COLUMN': data[0]}
            TDTSCHEMAORDER.append(row)
        #(아래)TDT스키마 정보가 담긴 변수
        TDTSCHEMAORDER[0]['COLUMN']
        TDTSCHEMALIST = TDTSCHEMAORDER[0]['COLUMN'].split(',')

        mappingDict = {}
        mapNum = 0


        for i in range(len(TDTSCHEMALIST)):
            mapNum = ORIGINALSCHEMALIST.index(TDTSCHEMALIST[i])
            mappingDict[i] = mapNum

        #파싱데이터 테이블 생성
        CreatedTableAddress = 'parsed_'+user+'_'+str(taskId)+'_'+submitNum
        CreatedTableQuery = 'CREATE TABLE ' +CreatedTableAddress +'('
        for i in range(len(TDTSCHEMALIST)):
            CreatedTableQuery = CreatedTableQuery + str(TDTSCHEMALIST[i])+' VARCHAR(300)'
            if i == len(TDTSCHEMALIST) -1:
                CreatedTableQuery = CreatedTableQuery+') ENGINE = INNODB;'
            else:
                CreatedTableQuery = CreatedTableQuery+','

        strSql = CreatedTableQuery
        result = cursor.execute(strSql)

        #PARSEDINFO 테이블에 데이터 추가 후 parsedid 얻어오기
        strsql ='''insert into PARSEDINFO(FILEADDR)  values('%s');'''%(CreatedTableAddress)
        result = cursor.execute(strsql)
        strsql = '''select ID
                        from PARSEDINFO
                        where FILEADDR = '%s' '''%(CreatedTableAddress)
        result = cursor.execute(strsql)
        parsedId = cursor.fetchall()

        parsedId = int(parsedId[0][0])

        #파싱데이터 테이블에 파일 저장

        for i in range(1,len(csv_list)):
            if(len(csv_list[i]) < len(TDTSCHEMALIST)):
                break;
            values = ''
            for j in range(len(TDTSCHEMALIST)):
                if(j !=len(TDTSCHEMALIST)-1):
                    values = values + '\"' + csv_list[i][mappingDict[j]] + '\"'+','
                else:
                    values = values + '\"' + csv_list[i][mappingDict[j]][:-1] + '\"'

            strsql = '''insert into %s values(%s);'''%(CreatedTableAddress, values)
            result = cursor.execute(strsql)

        #originalinfo 튜플추가
        strsql = '''insert into ORIGINALINFO(NTH,STARTDATE,ENDDATE,TYPENUM,MEMID,PARSEDID) values('%d','%s','%s','%d','%s','%d');'''%(int(submitNum),startDate,endDate,serialNum,user,parsedId)
        result = cursor.execute(strsql)
        #정량평가 요소 넣기
        quantityCheck(CreatedTableAddress,parsedId,cursor)

        #평가자 랜덤배정
        evalDesignate(parsedId,cursor)

        #APPLY totalsubmission 반영
        strsql = "UPDATE APPLY SET TOTALSUBMISSION ='%d' where MEMID = '%s' and TASKID = '%d' ;"%(int(submitNum),user,taskId)
        result = cursor.execute(strsql)
        connection.commit()
        connection.close()


    except Exception as e:
        logging.getLogger("error_logger").error("Unable to upload file. "+repr(e))
        messages.error(request,"Unable to upload file. "+repr(e))

    return HttpResponseRedirect(reverse("submitter:submitMain"))


def taskCheck(request, taskid):
    user = request.session.get('user')
    if user is None:
        return render(request, 'submitter/wrongAccess.html')

    cursor = connection.cursor()
    sql = "SELECT ORIGINALDATATYPE.NAME, ORIGINALINFO.NTH, ORIGINALINFO.STARTDATE, ORIGINALINFO.ENDDATE,\
            PARSEDINFO.TOTALTUPLE-PARSEDINFO.DUPLICATETUPLE, PARSEDINFO.PNP\
            FROM ORIGINALINFO, ORIGINALDATATYPE, PARSEDINFO\
            WHERE ORIGINALINFO.MEMID = '{}' and ORIGINALDATATYPE.TASKID = {} and\
            ORIGINALINFO.TYPENUM = ORIGINALDATATYPE.SERIALNUM and\
            ORIGINALINFO.PARSEDID = PARSEDINFO.ID ORDER BY ORIGINALINFO.TYPENUM, ORIGINALINFO.NTH;".format(user, taskid)
    result = cursor.execute(sql)
    submissions = cursor.fetchall()

    submit_result = []
    for submit in submissions:
        row = {'dt_name':submit[0], 'nth':submit[1],
                'period':"{} ~ {}".format(submit[2],submit[3]),
                'tuple_num':submit[4],
                'pnp':submit[5]}
        submit_result.append(row)

    sql = "SELECT project.APPLY.TOTALSUBMISSION, project.APPLY.ACCEPTEDTUPLE FROM project.APPLY where project.APPLY.MEMID = '{}' and project.APPLY.TASKID = {};".format(user, taskid)
    result = cursor.execute(sql)
    total_result = cursor.fetchall()
    total_result = {'total_submit':total_result[0][0], 'total_pass':total_result[0][1]}

    return render(request, 'submitter/taskCheck.html', {'submit_result':submit_result, 'total_result':total_result})


def quantityCheck(tableName, ID, cursor):

        try:
            strSql = "SELECT * FROM %s"%(tableName)
            result = cursor.execute(strSql)
            paresedTable = cursor.fetchall()


            total_tup = len(paresedTable)
            #중복 튜플 수 검사
            tempSet = set(paresedTable)
            dupli_tup = total_tup - len(tempSet)


            #null 개수 검사
            null_num = 0
            for i in range(total_tup):
                for j in range(len(paresedTable[0])):
                    if paresedTable[i][j] in ('\r','\n',''):
                        null_num +=1;

            total_ele = total_tup * len(paresedTable[0])

            null_ratio = round(null_num / total_ele, 5)

            #정성평가 지표 집어넣기
            strsql = "UPDATE PARSEDINFO SET TOTALTUPLE='%d', DUPLICATETUPLE='%d', NULLRATIO='%f' where ID = '%d';"%(total_tup,dupli_tup,null_ratio,ID)
            result = cursor.execute(strsql)
        except:
            connection.rollback()
            print("Failed to get Data")

        return

def evalDesignate(ID, cursor):
    try:
        strsql = '''select ID
                        from MEMBER
                        where ROLE = 'E' '''
        result = cursor.execute(strsql)
        evaluators = cursor.fetchall()


        eval_count = len(evaluators)
        random_num = random.randint(0,eval_count-1)

        random_evalid = evaluators[random_num][0]

        strsql = "UPDATE PARSEDINFO SET EVALID='%s' where ID = '%d';"%(random_evalid,ID)
        result = cursor.execute(strsql)


    except:
        connection.rollback()
        print("Failed to get Data")

    return
