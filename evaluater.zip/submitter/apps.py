from django.apps import AppConfig


class SubmitterConfig(AppConfig):
    name = 'submitter'
