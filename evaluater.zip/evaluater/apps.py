from django.apps import AppConfig


class EvaluaterConfig(AppConfig):
    name = 'evaluater'
